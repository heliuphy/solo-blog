title: 怎么提取chrome浏览器扩展的crx文件？
date: '2019-10-29 19:31:31'
updated: '2019-10-29 21:14:40'
tags: [chrome]
permalink: /articles/2019/10/29/1572348691596.html
---
大概思路就是进入 https://chrome-extension-downloader.com/  这个网站，提取到crx文件，拖进chrome内即可完成。
下面分步骤说明：
## 获得扩展的url
比如随便找一个：
![](https://pic.stdstring.com/20191029200250.png)
这里就可以看到这个扩展的url，将这个url复制下来，下一步会用到。
## 从Chrome Extension Downloader网站提取crx
进入网站 https://chrome-extension-downloader.com/ ，在输入框中粘贴刚刚得到的url，点击右边的按钮“download extention 即可下载得到crx文件。
## 拖进chrome浏览器中
打开chrome的扩展管理页面，将crx拖进来。
此时，有一定的可能显示”crx 程序包无效“，这个时候解决办法如下：
## 应对crx 程序包无效
1. 将.crx后缀改为.rar；
2. 解压这个rar文件；
3. 在chrome插件管理页面选择”加载已解压的扩展程序“，然后选择刚刚的那文件夹即可。
