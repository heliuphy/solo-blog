title: 使用brew升级Mac上的vim
date: '2019-11-14 22:48:17'
updated: '2019-11-14 22:48:17'
tags: [vim, MAC]
permalink: /articles/2019/11/14/1573742897747.html
---
## 使用brew安装最新版的vim
直接执行以下命令：
```
brew install vim
```
安装完成后，敲`vim`命令发现还是系统自带的vim。这个时候可以使用别名来替换。因为我使用的是zsh，所以更改`~/.zshrc`，如果你使用的是bash的话，更改`~/.bashrc`是一样的。
```
vim ~/.zshrc

# 在文件末尾添加一行：
alias vim="/usr/local/Cellar/vim/8.1.2250/bin/vim"

# 回到命令行，执行命令
source ~/.zshrc
```

## 问题处理
执行完上面的步骤，再进入vim，发现出现以下报错
```
E484: Can't open file /usr/local/share/vim/syntax/syntax.vim
Press ENTER or type command to continue
```
这估计是vim的share目录还是以前的，这里我们可以建立一个软连接，指向我们最新安装的vim的share目录就可以了
```
ln -s /usr/local/Cellar/vim/8.1.2250/share/vim/vim81 /usr/local/share/vim
```

## 附
### ln 命令
```
Creates links to files and directories.

# Create a symbolic link to a file or directory:

  ln -s path/to/file_or_directory path/to/symlink

# Overwrite an existing symbolic to point to a different file:

  ln -sf path/to/new_file path/to/symlink

# Create a hard link to a file:

  ln path/to/file path/to/hardlink
```
