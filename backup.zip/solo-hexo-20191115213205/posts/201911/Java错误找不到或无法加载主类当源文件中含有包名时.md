title: Java 错误：找不到或无法加载主类，当源文件中含有包名时
date: '2019-11-14 16:11:32'
updated: '2019-11-14 16:11:32'
tags: [java, bug]
permalink: /articles/2019/11/14/1573719092582.html
---
在源文件中含有包名时，如果没有建立正确的文件路径可能会遇到以下错误：
```java
错误: 找不到或无法加载主类 Main.class
原因: java.lang.ClassNotFoundException: Main.class
```

解决办法：
假如源文件的包名为`com.hello`
那么需要按照包名创建路径：
```bash
mkdir -p com/hello
```

然后在当前目录执行：
```bash
javac com/hello/Main.java
java com.hello.Main
```

就可以了。
